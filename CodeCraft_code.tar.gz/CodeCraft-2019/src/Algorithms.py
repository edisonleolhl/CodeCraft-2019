"""
This file contains some useful function in altgraph module,
but we have to modify some details to cooperate with our environment
"""
from altgraph import GraphError

class Algorithms(object):
    def __init__(self):
        """
        Initialization
        """

    def dijkstra(self, graph, start, end=None, usedByYenKSP=False, car_speed=0):
        D = {}    # dictionary of final distances
        P = {}    # dictionary of predecessors
        Q = self._priorityDictionary()    # estimated distances of non-final vertices
        Q[start] = 0

        for v in Q:
            D[v] = Q[v]
            if v == end:
                break

            # graph.out_nbrs(v): Return a list of all nodes connected by outgoing edges.
            for w in graph.out_nbrs(v):
                edge_id = graph.edge_by_node(v, w)
                # edge_weight = road_length/speed_limit/channel_number
                # max_speed = min(car_speed, graph.edge_data(edge_id)[2])
                # vwLength = D[v] + graph.edge_data(edge_id)[1] / max_speed / graph.edge_data(edge_id)[3]
                # vwLength = D[v] + graph.edge_data(edge_id)[1] / graph.edge_data(edge_id)[2] / graph.edge_data(edge_id)[3]
                vwLength = D[v] + graph.edge_data(edge_id)[1] / graph.edge_data(edge_id)[3]

                # vwLength = D[v] + graph.edge_data(edge_id)
                if w in D:
                    if vwLength < D[w]:
                        raise GraphError(
                            "Dijkstra: found better path to already-final vertex")
                elif w not in Q or vwLength < Q[w]:
                    Q[w] = vwLength
                    P[w] = v


        if usedByYenKSP:
            if end:
                if end not in graph.forw_bfs(start):  # can not reach end_node from start_node
                    return {'cost': D[start],
                            'path': []}
                return {'cost': D[end],
                        'path': self.path(P, start, end)}
            else:
                return (D, P)
        else:
            return (D, P)


    def shortest_path(self, graph, start, end, car_speed=0):
        """
        Find a single shortest path from the *start* node to the *end* node.
        The input has the same conventions as dijkstra(). The output is a list of
        the nodes in order along the shortest path.

        **Note that the distances must be stored in the edge data as numeric data**
        """

        D, P = self.dijkstra(graph, start, end, False, car_speed)
        Path = []
        if end not in P:
            return
        while 1:
            Path.append(end)
            # if end not in P:
            #     break
            if end == start:
                break
            end = P[end]
        Path.reverse()
        return Path


    class _priorityDictionary(dict):

        def __init__(self):

            self.__heap = []
            dict.__init__(self)

        def smallest(self):

            if len(self) == 0:
                raise IndexError("smallest of empty priorityDictionary")
            heap = self.__heap
            while heap[0][1] not in self or self[heap[0][1]] != heap[0][0]:
                lastItem = heap.pop()
                insertionPoint = 0
                while 1:
                    smallChild = 2*insertionPoint+1
                    if smallChild+1 < len(heap) and \
                            heap[smallChild] > heap[smallChild+1]:
                        smallChild += 1
                    if smallChild >= len(heap) or lastItem <= heap[smallChild]:
                        heap[insertionPoint] = lastItem
                        break
                    heap[insertionPoint] = heap[smallChild]
                    insertionPoint = smallChild
            return heap[0][1]

        def __iter__(self):
            def iterfn():
                while len(self) > 0:
                    x = self.smallest()
                    yield x
                    del self[x]
            return iterfn()

        def __setitem__(self, key, val):
            dict.__setitem__(self, key, val)
            heap = self.__heap
            if len(heap) > 2 * len(self):
                self.__heap = [(v, k) for k, v in self.items()]
                self.__heap.sort()
            else:
                newPair = (val, key)
                insertionPoint = len(heap)
                heap.append(None)
                while insertionPoint > 0 and newPair < heap[(insertionPoint-1)//2]:
                    heap[insertionPoint] = heap[(insertionPoint-1)//2]
                    insertionPoint = (insertionPoint-1)//2
                heap[insertionPoint] = newPair

        def setdefault(self, key, val):
            if key not in self:
                self[key] = val
            return self[key]